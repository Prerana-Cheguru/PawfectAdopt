import './App.css';
import {
  NavBarHeader,
  Pets,
  MarketingFooterBrand
} from './ui-components';
import { signOut } from 'aws-amplify/auth';
import { HashRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import AddPet from './AddPet';
import PetProfilePage from './PetProfilePage';
import UpdatePetProfilePage from './UpdatePetProfilePage';
import { DataStore } from '@aws-amplify/datastore';

/**
 * HomePage Component
 *
 * @component
 * @description
 * The homepage component that displays a grid of pets using the Pets component.
 * It also includes a custom navigation bar and a marketing footer.
 *
 * @example
 * return <HomePage />
 */
function HomePage() {
  function NavBar() {
    const navigate = useNavigate();

    const overrideNavBar = {
      Home: {
        style: { cursor: 'pointer' },
        onClick: () => navigate('/') // Redirect on HOME click
      },
      PETSTORE: {
        style: { cursor: 'pointer' },
        onClick: () => navigate('/AddPet') // Redirect on PETSTORE click
      },
      'Sign Out': {
        style: { cursor: 'pointer' },
        onClick: () => {
          if (window.confirm('Are you sure you want to sign out?')) {
            signOut();
          }
        }
      }
    };

    return <NavBarHeader width={'100%'} overrides={overrideNavBar} />;
  }

  const overrideFooter = {
    'React.JS': { style: { cursor: 'pointer' } },
    Figma: { style: { cursor: 'pointer' } },
    'AWS DynamoDB': { style: { cursor: 'pointer' } },
    'AWS Amplify': { style: { cursor: 'pointer' } }
  };

  const navigate = useNavigate();

  return (
    <div>
      <NavBar />
      <header
        style={{
          backgroundColor: '#E0FFFF',
          padding: '1rem'
        }}
      >
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '1.5rem',
            width: '100%',
            boxSizing: 'border-box'
          }}
        >
          <Pets
            overrideItems={({ item }) => ({
              overrides: {
                Button29766907: {
                  style: { cursor: "pointer" },
                  onClick: () => {
                    navigate(`/pet-profile?id=${item.id}`);
                  },
                },
                Button3858564: {
                  style: { cursor: "pointer" },
                  onClick: () => {
                    navigate(`/update-pet?id=${item.id}`);
                  },
                },
                Button3858656: {
                  style: { cursor: "pointer" },
                  onClick: () => {
                    if (window.confirm('Are you sure you want to delete this pet?')) {
                      DataStore.delete(item);
                    } else {
                      alert('Pet not deleted');
                    }
                  },
                },
              },
            })}
          />
                  </div>
                </header>
                <MarketingFooterBrand width={'100%'} overrides={overrideFooter} />
              </div>
            );
          }

function App() {
  return (

    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/AddPet" element={<AddPet />} />
          <Route path="/pet-profile" element={<PetProfilePage />} />
          <Route path="/update-pet" element={<UpdatePetProfilePage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
