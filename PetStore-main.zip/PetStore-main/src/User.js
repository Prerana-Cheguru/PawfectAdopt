import { HashRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { NavBarHeader, Pets, MarketingFooterBrand } from './ui-components';
import { signOut } from 'aws-amplify/auth';
import PetProfilePage from './PetProfilePage';

/**
 * HomePage Component
 *
 * @component
 * @description
 * Displays the main homepage with a grid of pet cards using the Pets component.
 * Includes a custom navigation bar with Home and Sign Out actions and hides PETSTORE.
 * Buttons inside each pet card are also hidden using overrideItems, with clickable pet cards navigating to profiles.
 *
 * @example
 * return <HomePage />
 */
function Homepage() {

  function NavBar() {
    const navigate = useNavigate();

    const overrideNavBar = {
      Home: {
        style: { cursor: "pointer" },
        onClick: () => navigate('/')
      },
      PETSTORE: {
        children: "",
        style: { display: "none" }
      },
      "Sign Out": {
        style: { cursor: "pointer" },
        onClick: () => {
          if (window.confirm("Are you sure you want to sign out?")) {
            signOut();
          }
        }
      }
    };
    return <NavBarHeader width={"100%"} overrides={overrideNavBar} />;
  }

  const overrideFooter = {
    "React.JS": { style: { cursor: "pointer" } },
    "Figma": { style: { cursor: "pointer" } },
    "AWS DynamoDB": { style: { cursor: "pointer" } },
    "AWS Amplify": { style: { cursor: "pointer" } },
  };

  const navigate = useNavigate();

  return (
    <div>
      <NavBar />
      <header
        style={{
          backgroundColor: "#E0FFFF",
          padding: "1rem",
        }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
            gap: "1.5rem",
            width: "100%",
            boxSizing: "border-box",
            padding: "5rem",
          }}
        >
          <Pets
            overrideItems={({ item }) => ({
                overrides: {
                Button3858656: { style: { display: "none" } },
                Button3858564: { style: { display: "none" } },
                Button29766907: {
                    style: { cursor: "pointer" },
                    onClick: () => {
                    console.log('Navigating to pet profile with ID:', item.id);
                    navigate(`/pet-profile?id=${item.id}`);
                    },
                },
                },
            })}
            />

        </div>
      </header>
      <MarketingFooterBrand width={"100%"} overrides={overrideFooter} />
    </div>
  );
}

function App() {
    return (
      <Router>
        <div className="App">
          <Routes>
            <Route path="/" element={<Homepage />} />
            <Route path="/pet-profile" element={<PetProfilePage />} />
          </Routes>
        </div>
      </Router>
    );
  }

export default App;
