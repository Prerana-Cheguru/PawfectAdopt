import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { DataStore } from '@aws-amplify/datastore';
import { Pet } from './models';
import { NavBarHeader, MarketingFooterBrand, ProfileCard } from './ui-components';

/**
 * ProfilePetNavBar Component
 *
 * @component
 * @description
 * Custom navigation bar for the Pet Profile page.
 * Provides navigation to the homepage and hides PETSTORE and Sign Out buttons.
 *
 * @example
 * return <ProfilePetNavBar />
 */
function ProfilePetNavBar() {
  const navigate = useNavigate();

  const overrideNavBar = {
    Home: {
      style: { cursor: "pointer" },
      onClick: () => navigate('/')
    },
    PETSTORE: {
      children: ""
    },
    "Sign Out": {
      children: ""
    }
  };

  return <NavBarHeader width={"100%"} overrides={overrideNavBar} />;
}

/**
 * PetProfilePage Component
 *
 * @component
 * @description
 * Displays detailed information for a specific pet.
 * Fetches pet data by ID from AWS DataStore and shows it in a ProfileCard component.
 * Includes a custom navigation bar and a marketing footer.
 *
 * - Uses query parameters to fetch pet ID (compatible with HashRouter).
 * - Displays loading and error states.
 * - Uses ProfileCard component to display pet details.
 *
 * @example
 * return <PetProfilePage />
 */
function PetProfilePage() {
  const [searchParams] = useSearchParams();
  const id = searchParams.get('id');
  const [pet, setPet] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  const overrideFooter = {
    "React.JS": { style: { cursor: "pointer" } },
    "Figma": { style: { cursor: "pointer" } },
    "AWS DynamoDB": { style: { cursor: "pointer" } },
    "AWS Amplify": { style: { cursor: "pointer" } },
  };

  useEffect(() => {
    const fetchPet = async () => {
      if (!id) {
        setError("Invalid or missing pet ID in URL.");
        setLoading(false);
        return;
      }

      try {
        const petData = await DataStore.query(Pet, id);
        if (petData) {
          setPet(petData);
        } else {
          setError("Pet not found.");
        }
      } catch (err) {
        console.error('Error fetching pet:', err);
        setError("Error fetching pet data.");
      } finally {
        setLoading(false);
      }
    };
    fetchPet();
  }, [id]);

  if (loading) {
    return <div style={{ padding: '2rem' }}>Loading pet details...</div>;
  }

  if (error) {
    return <div style={{ padding: '2rem', color: 'red' }}>{error}</div>;
  }

  return (
    <div style={{ backgroundColor: "#2d2f34" }}>
      <ProfilePetNavBar />
      <div style={{ display: 'flex', justifyContent: 'center', padding: '2rem' }}>
        <ProfileCard pet={pet} />
      </div>
      <MarketingFooterBrand width={"100%"} overrides={overrideFooter} />
    </div>
  );
}

export default PetProfilePage;
