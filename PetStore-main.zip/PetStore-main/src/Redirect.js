import React, { useEffect, useState } from 'react';
import { withAuthenticator } from '@aws-amplify/ui-react';
import { fetchAuthSession } from 'aws-amplify/auth';
import App from './App';
import User from './User.js';

/**
 * Redirector Component
 *
 * @component
 * @description
 * Handles post-authentication routing based on user group membership.
 * Fetches the authenticated session, checks if the user belongs to the 'Developer' group,
 * and redirects accordingly to either the main App component or a User component.
 *
 * - Displays a loading indicator while session data is being fetched.
 * - Logs session details and group information to the console for debugging.
 *
 * @example
 * return <Redirector />
 */
const Redirector = () => {
  const [loading, setLoading] = useState(true);
  const [isDeveloper, setIsDeveloper] = useState(false);

  useEffect(() => {
    fetchAuthSession()
      .then((session) => {
        console.log('Full Auth Session:', session);
        const groups = session.tokens?.accessToken?.payload["cognito:groups"] || [];
        console.log('Groups:', groups);
        if (groups.includes('Developer')) {
          setIsDeveloper(true);
        }
      })
      .catch((err) => {
        console.error('Error fetching session:', err);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div>Loading...</div>;

  if(isDeveloper){
    return <div><title>PetStore-Dev</title><App/></div>
  }else{
    return <div><title>PetStore-Usr</title><User/></div>
  }
};

export default withAuthenticator(Redirector);
